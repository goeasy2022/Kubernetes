#!/bin/bash
#
#1. 禁用交换分区: 全部主机

ansible all -m shell -a "sed -r -i.bak '/swap/s@(.*)@#\1@' /etc/fstab"

#2. 内核参数调整: 全部主机

ansible all -m copy -a "src=limits.conf dest=/etc/security/limits.conf backup=yes"
ansible all -m copy -a "src=sysctl.conf dest=/etc/sysctl.conf backup=yes"

#3. 重启生效
ansible all -m shell -a "reboot"
