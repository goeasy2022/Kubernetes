#!/bin/bash
#

#GREEN="echo -e \033[1;32m"
RED="echo -e \033[1;31m"
END="\033[0m"

#1. set hostname
hostnamectl set-hostname ansible
#2. install ansible
yum -y install ansible || { ${RED}ansible installation failed!${END}; exit 1; }
#3. enable ansible log
sed -r -i -e "s@#(log_path = /var/log/ansible.log)@\1@" -e "s@#(module_name = command)@\1@" /etc/ansible/ansible.cfg
#4. append hosts list to hosts.cfg
cat hosts_ansible.list >> /etc/ansible/hosts
#5. verify hosts list
ansible all --list-hosts
sleep 5
#6. continue with ssh authentication
while read -p "Do you want to continue? " REPLY; do
case $REPLY in
[Yy] | [Yy][Ee][Ss])
    ${RED}'ready for ssh authentication!'${END}
    sleep 5;
    break
    ;;
[Nn] | [Nn][Oo])
    ${RED}quit script!${END}
    exit 1
    ;;
*)
    ${RED}Wrong input!${END}
    ;;
    esac
done
#7. ssh authentication
rpm -q sshpass &> /dev/null || yum -y install sshpass  
[ -f /root/.ssh/id_rsa ] || ssh-keygen -f /root/.ssh/id_rsa  -P ''
export SSHPASS=000000
while read IP;do
   sshpass -e ssh-copy-id  -o StrictHostKeyChecking=no $IP
done < hosts_ssh.list
ansible all -m ping
